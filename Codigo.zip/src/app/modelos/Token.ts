export class tokens {
    constructor(tokenBd="Token123"){
        this.tokenBd=tokenBd;
    }
    tokenBd:string;
}
